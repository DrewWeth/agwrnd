class Puppy < ActiveRecord::Base
	has_many :puppy_images
end
