class Utility < ActiveRecord::Base
end
