Drew Wetherington
14160293


Deployed App URL
------------------------
http://puppypower.herokuapp.com/


Github Repo
-----------------------------------
https://github.com/DrewWeth/puppies


Info
----
This assignment is implemented with the Ruby on Rails web framework. It is deployed on heroku.com and uses a postgres database. I emailed you about using Django in lieu of a PHP framework, but chose Rails in order to practicing image uploading and CMS techniques on this assignment.