class HomeController < ApplicationController
	def involve
	end
end
